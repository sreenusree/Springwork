package service;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;

	import com.beans.Registrationbean;

	import connection.dbconnection;;

	public class Reg { 
		Connection con=dbconnection.getconnection();

		public int Reg(Registrationbean regbeans) {
			// TODO Auto-generated method stub
			
			System.out.println("inside insert");
			String sql="insert into reg(fname,surname,email,password,mobile,fileToUpload) values(?,?,?,?,?,?)";
			try {
				java.sql.PreparedStatement ps=con.prepareStatement(sql);
				System.out.println(sql);
				ps.setString(1,Registrationbean.getFname());
				ps.setString(2,Registrationbean.getSurname());
				ps.setString(3,Registrationbean.getEmail());
				ps.setString(4,Registrationbean.getPasswordl());
				ps.setString(5,Registrationbean.getMobile());
				ps.setString(6,Registrationbean.getFileuploader());
				System.out.println(Registrationbean.getFname());
				ps.executeUpdate();
				System.out.println(Registrationbean.getSurname());
				System.out.println(Registrationbean.getEmail());
				System.out.println(Registrationbean.getPasswordl());
				System.out.println(Registrationbean.getMobile());
				
				ResultSet rs=ps.getGeneratedKeys();
			if(rs.next())
			{return rs.getInt(1);}
			
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
			return 0;
		

		
			
		
		
		
		

	}

}
