package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class dbconnection {
	


	public static class DbConnection {
		public static  Connection getConnection(){
	 
		Connection con=null;
		try{
			 
			Class.forName("com.mysql.jdbc.Driver");
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcon", "root", "root" );
			 System.out.println("connected");
			 
			 
		 
		}catch(Exception e){
			e.printStackTrace();
		}
		return con;
		 
	}}
		


}